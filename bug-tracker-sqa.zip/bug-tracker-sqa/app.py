
from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('sqa.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS bugs (id INTEGER PRIMARY KEY, title TEXT, description TEXT, severity TEXT, assigned_to TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS test_cases (id INTEGER PRIMARY KEY, title TEXT, steps TEXT, expected_result TEXT)''')
    conn.commit()
    conn.close()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/bugs')
def view_bugs():
    conn = sqlite3.connect('sqa.db')
    c = conn.cursor()
    c.execute("SELECT * FROM bugs")
    bugs = c.fetchall()
    conn.close()
    return render_template('bugs.html', bugs=bugs)

@app.route('/add_bug', methods=['GET', 'POST'])
def add_bug():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        severity = request.form['severity']
        assigned_to = request.form['assigned_to']
        conn = sqlite3.connect('sqa.db')
        c = conn.cursor()
        c.execute("INSERT INTO bugs (title, description, severity, assigned_to) VALUES (?, ?, ?, ?)", 
                  (title, description, severity, assigned_to))
        conn.commit()
        conn.close()
        return redirect('/bugs')
    return render_template('bug_form.html')

@app.route('/test_cases')
def view_test_cases():
    conn = sqlite3.connect('sqa.db')
    c = conn.cursor()
    c.execute("SELECT * FROM test_cases")
    test_cases = c.fetchall()
    conn.close()
    return render_template('test_cases.html', test_cases=test_cases)

@app.route('/add_test_case', methods=['GET', 'POST'])
def add_test_case():
    if request.method == 'POST':
        title = request.form['title']
        steps = request.form['steps']
        expected_result = request.form['expected_result']
        conn = sqlite3.connect('sqa.db')
        c = conn.cursor()
        c.execute("INSERT INTO test_cases (title, steps, expected_result) VALUES (?, ?, ?)", 
                  (title, steps, expected_result))
        conn.commit()
        conn.close()
        return redirect('/test_cases')
    return render_template('test_case_form.html')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
